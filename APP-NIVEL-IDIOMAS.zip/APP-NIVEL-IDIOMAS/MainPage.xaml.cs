﻿using System.ComponentModel;

namespace App_IDIOMAS
{
    public partial class MainPage : ContentPage, INotifyPropertyChanged
    {
        private int _contador = 0;
       
        public int Contador
        {
            get => _contador;
            set
            {
                if (_contador != value)
                {
                    _contador = value;
                    OnPropertyChanged();
                }
            }
        }
        public MainPage()
        {
            InitializeComponent();
            BindingContext = this;
        }

        private async void InsertarValenciano_Clicked(object sender, EventArgs e)
        {
            string nivelValenciano = await DisplayActionSheet("Nivel de Valenciano",
            "Cancell", "Delete", "Avanzado", "Medio","Basico");

            if (nivelValenciano == "Avanzado"){
                ValencianoEntry.Text = "A";
            }

            if (nivelValenciano == "Medio")
            {
                ValencianoEntry.Text = "M";
            }

            if (nivelValenciano == "Basico")
            {
                ValencianoEntry.Text = "B";
            }

            if (nivelValenciano == "Delete")
            {
                FrancesEntry.Text = "";
            }

            OnPropertyChanged();
        }

        private async void InsertarIngles_Clicked(object sender, EventArgs e)
        {
            string nivelIngles = await DisplayActionSheet("Nivel de Ingles",
            "Cancell", "Delete", "Avanzado", "Medio", "Basico");

            if (nivelIngles == "Avanzado")
            {
                InglesEntry.Text = "A";
            }

            if (nivelIngles == "Medio")
            {
                InglesEntry.Text = "M";
            }

            if (nivelIngles == "Basico")
            {
                InglesEntry.Text = "B";
            }

            if (nivelIngles == "Delete")
            {
                FrancesEntry.Text = "";
            }

            OnPropertyChanged();
        }

        private async void InsertarFrances_Clicked(object sender, EventArgs e)
        {
            string nivelFrances = await DisplayActionSheet("Nivel de Frances",
            "Cancell", "Delete", "Avanzado", "Medio", "Basico");

            if (nivelFrances == "Avanzado")
            {
                FrancesEntry.Text = "A";
            }

            if (nivelFrances == "Medio")
            {
                FrancesEntry.Text = "M";
            }

            if (nivelFrances == "Basico")
            {
                FrancesEntry.Text = "B";
            }

            if (nivelFrances == "Delete")
            {
                FrancesEntry.Text = "";
            }
                
        }

        private async void btnComprobar_Clicked(object sender, EventArgs e)
        {

            Contador = 0;
            
            
                if (ValencianoEntry.Text == "A")
                {
                Contador++;
                }

                if (InglesEntry.Text == "A")
                {
                Contador++;
                }

                if (FrancesEntry.Text == "A")
                {
                Contador++;
                }
            

            bool answer = await DisplayAlert("Boton de comprobar", "Quieres comprobar", "SI", "NO");

            if (answer)
            {
                tvContador.Text = $"Nivel de avanzado: {Contador}";
                OnPropertyChanged();
            }

        }

        private async void btnCreditos_Clicked(object sender, EventArgs e)
        {
            await DisplayAlert("Trabajo realizado por", "Alejandro Roberto Chiralt", "OK");
        }

        
    }

}
