﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace AppAlmacenarBaseDeDatos
{
    public class Trabajador : INotifyPropertyChanged
    {
      
        public string NombreObjeto { get; set; }

        public string ApellidosObjeto { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        public override string ToString()
        {
            return $"Nombre: {NombreObjeto}, Apellidos: {ApellidosObjeto}";
        }
    }
}
