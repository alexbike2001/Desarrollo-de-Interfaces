﻿using Microsoft.Data.Sqlite;
using Microsoft.Maui.Controls;
using System.Collections.ObjectModel;
using System.Data.SQLite;
using System.Reflection.PortableExecutable;
using System.Xml.Linq;

namespace AppAlmacenarBaseDeDatos
{
    public partial class MainPage : ContentPage
    {

        private string _nombre;
        public string Nombre
        {
            get
            {
                return this._nombre;
            }
            set
            {
                if ((this._nombre != value))
                {
                    this._nombre = value;
                }
            }
        }

        private string _apellidos;
        public string Apellidos
        {
            get
            {
                return this._apellidos;
            }
            set
            {
                if (this._apellidos != value)
                {
                    this._apellidos = value;
                }
            }
        }

        private string _nombreSeleccionado;
        public string NombreSeleccionado
        {
            get
            {
                return this._nombreSeleccionado;
            }
            set
            {
                if(this._nombreSeleccionado != value){
                    this._nombreSeleccionado = value;
                }
                    
            }
        }

        private string _apellidoSeleccionado;
        public string ApellidoSeleccionado
        {
            get
            {
                return this._apellidoSeleccionado;
            }
            set
            {
                if (this._apellidoSeleccionado != value)
                {
                    this._apellidoSeleccionado = value;
                }

            }
        }

        private Trabajador _selectedTrabajador;
        public Trabajador SelectedTrabajador
        {
            get
            {
                return this._selectedTrabajador;
            }
            set
            {
                _selectedTrabajador = value;
                OnPropertyChanged();
            }
        }

        private ObservableCollection<Trabajador> _ocTrabajadores;
        public ObservableCollection<Trabajador> OcTrabajadores
        {
            get { return _ocTrabajadores; }
            set
            {
                _ocTrabajadores = value;
                OnPropertyChanged();
            }
        }


        public MainPage()
        {
            InitializeComponent();
            OcTrabajadores = new ObservableCollection<Trabajador>();

            //CREAR BD
            string rutaDirectorioApp = System.AppContext.BaseDirectory;
            DirectoryInfo directorioApp = new DirectoryInfo(rutaDirectorioApp);
            directorioApp = directorioApp.Parent.Parent.Parent.Parent.Parent.Parent;
            string databasePath = Path.Combine(directorioApp.FullName, "empresa1.db");
            string connectionString = $"Data Source={databasePath};Version=3;";
            try
            {
                if (!File.Exists(databasePath))
                {
                    using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                    {
                        connection.Open();

                        DisplayAlert("Éxito", "Conexión exitosa con la base de datos.", "OK");

                        string queryCrearTabla = @"
                            CREATE TABLE IF NOT EXISTS Trabajador (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            nombre TEXT NOT NULL,
                            apellidos TEXT NOT NULL
                            );";

                        using (SQLiteCommand command = new SQLiteCommand(queryCrearTabla, connection))
                        {
                            command.ExecuteNonQuery();
                        }

                        connection.Close();

                    }
                }

                    
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", $"Error al insertar en la base de datos: {ex.Message}", "OK");
            }


            //CONSULTA
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                // Creamos la consulta y la ejecutamos
                string sql = "SELECT * FROM Trabajador";
                SQLiteCommand command = new SQLiteCommand(sql, connection);
                SQLiteDataReader reader = command.ExecuteReader();

                // Recorremos los registros devueltos del SELECT
                while (reader.Read())
                {
                    
                    string _nombre = reader.GetString(1);
                    string _apellidos = reader.GetString(2);

                    // Creamos un objeto Trabajador y lo añadimos al Observable Collection
                    Trabajador trabajador = new Trabajador
                    {
                        NombreObjeto = _nombre,
                        ApellidosObjeto = _apellidos,
                    };

                    // Añadimos el trabajador al Observable Collection
                    OcTrabajadores.Add(trabajador);
                }

                reader.Close();
                connection.Close();
            }

            BindingContext = this;

        }

        

        private async void btnAñadirTrabajador_Clicked(object sender, EventArgs e)
        {
            // Capturar los datos de entrada
            _nombre = etNombre.Text;
            _apellidos = etApellidos.Text;

            // Validar que no sean nulos o vacíos
            if (string.IsNullOrWhiteSpace(_nombre) || string.IsNullOrWhiteSpace(_apellidos))
            {
                Console.WriteLine("El nombre o los apellidos están vacíos.");
                DisplayAlert("Fail","Nombre o apellidos vacio", "OK");
                return;
            }

            // Crear un nuevo trabajador
            Trabajador trabajador = new Trabajador
            {
                NombreObjeto = _nombre,
                ApellidosObjeto = _apellidos,
            };

            

            // Notificar cambio en la colección (para bindings en la UI)
            OnPropertyChanged(nameof(OcTrabajadores));

            // Guardar en la base de datos
            string rutaDirectorioApp = System.AppContext.BaseDirectory;
            DirectoryInfo directorioApp = new DirectoryInfo(rutaDirectorioApp);
            directorioApp = directorioApp.Parent.Parent.Parent.Parent.Parent.Parent;
            string databasePath = Path.Combine(directorioApp.FullName, "empresa1.db");
            string connectionString = $"Data Source={databasePath};Version=3;";
            
            try
            {
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();

                    DisplayAlert("Éxito", "Conexión exitosa con la base de datos.", "OK");

                    string queryInsertar = "INSERT INTO Trabajador (nombre, apellidos) VALUES (@nombre, @apellidos)";

                    using (SQLiteCommand command = new SQLiteCommand(queryInsertar, connection))
                    {
                        command.Parameters.AddWithValue("@nombre", _nombre);
                        command.Parameters.AddWithValue("@apellidos", _apellidos);
                        int filasAfectadas = command.ExecuteNonQuery();
                        if (filasAfectadas > 0)
                        {
                            DisplayAlert("Trabajador añadido correctamente",
                             $"Nombre: {_nombre}\nApellidos: {_apellidos}",
                             "OK");
                        }
                        else
                        {
                            DisplayAlert("Error", "No se pudo insertar el trabajador.", "OK");
                        }
                    }
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", $"Error al insertar en la base de datos: {ex.Message}", "OK");
            }

            // Añadir a la colección
            OcTrabajadores.Add(new Trabajador { NombreObjeto = _nombre, ApellidosObjeto = _apellidos });

            

            // Limpiar los campos de entrada
            etNombre.Text = string.Empty;
            etApellidos.Text = string.Empty;

            
        }

        private void OnCollectionViewSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Obtener el elemento seleccionado
            var selectedTrabajador = e.CurrentSelection.FirstOrDefault() as Trabajador;

            if (selectedTrabajador != null)
            {
                // Realiza alguna acción con el trabajador seleccionado
                DisplayAlert("Trabajador Seleccionado",
                             $"Nombre: {selectedTrabajador.NombreObjeto}\nApellidos: {selectedTrabajador.ApellidosObjeto}",
                             "OK");

                etNombre.Text = selectedTrabajador.NombreObjeto;
                etApellidos.Text = selectedTrabajador.ApellidosObjeto;

                _nombreSeleccionado = SelectedTrabajador.NombreObjeto;
                _apellidoSeleccionado = SelectedTrabajador.ApellidosObjeto;

                OnPropertyChanged(nameof(OcTrabajadores));
            }
        }

        private void btnBorrarTrabajador_Clicked(object sender, EventArgs e)
        {
            
            // Borrar en la base de datos
            string rutaDirectorioApp = System.AppContext.BaseDirectory;
            DirectoryInfo directorioApp = new DirectoryInfo(rutaDirectorioApp);
            directorioApp = directorioApp.Parent.Parent.Parent.Parent.Parent.Parent;
            string databasePath = Path.Combine(directorioApp.FullName, "empresa1.db");
            string connectionString = $"Data Source={databasePath};Version=3;";

            try
            {
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();

                    DisplayAlert("Éxito", "Conexión exitosa con la base de datos.", "OK");

                    string queryInsertar = "DELETE FROM Trabajador WHERE nombre = @nombre AND apellidos = @apellidos";

                    using (SQLiteCommand command = new SQLiteCommand(queryInsertar, connection))
                    {
                        command.Parameters.AddWithValue("@nombre", SelectedTrabajador.NombreObjeto);
                        command.Parameters.AddWithValue("@apellidos", SelectedTrabajador.ApellidosObjeto);

                        int filasAfectadas = command.ExecuteNonQuery();
                        if (filasAfectadas > 0)
                        {
                            DisplayAlert("Trabajador borrado correctamente",
                             $"Nombre: {SelectedTrabajador.NombreObjeto}\nApellidos: {SelectedTrabajador.ApellidosObjeto}",
                             "OK");
                        }
                        else
                        {
                            DisplayAlert("Error", "No se pudo borrar el trabajador.", "OK");
                        }
                    }
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", $"Error al borrar de la base de datos: {ex.Message}", "OK");
            }

            OcTrabajadores.Remove(SelectedTrabajador);

            // Limpiar los campos de entrada
            etNombre.Text = string.Empty;
            etApellidos.Text = string.Empty;
        }

        private void btnActualizar_Clicked(object sender, EventArgs e)
        {
            // Actualizar en la base de datos
            string rutaDirectorioApp = System.AppContext.BaseDirectory;
            DirectoryInfo directorioApp = new DirectoryInfo(rutaDirectorioApp);
            directorioApp = directorioApp.Parent.Parent.Parent.Parent.Parent.Parent;
            string databasePath = Path.Combine(directorioApp.FullName, "empresa1.db");
            string connectionString = $"Data Source={databasePath};Version=3;";

            try
            {
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();

                    string queryActualizar = "UPDATE Trabajador SET nombre = @nombre, apellidos = @apellidos WHERE nombre = @nombreSelect AND apellidos = @apellidoSelect\r\n";
                    

                    // Capturar los datos de entrada
                    _nombre = etNombre.Text;
                    _apellidos = etApellidos.Text;

                    using (SQLiteCommand command = new SQLiteCommand(queryActualizar, connection))
                    {
                        
                        command.Parameters.AddWithValue("@nombre", _nombre);
                        command.Parameters.AddWithValue("@apellidos", _apellidos);
                        command.Parameters.AddWithValue("@nombreSelect", _nombreSeleccionado);
                        command.Parameters.AddWithValue("@apellidoSelect", _apellidoSeleccionado);

                        // Añadir a la colección
                        
                        OcTrabajadores.Add(new Trabajador { NombreObjeto = _nombre, ApellidosObjeto = _apellidos });
                        OnPropertyChanged(nameof(OcTrabajadores));
                        int filasAfectadas = command.ExecuteNonQuery();

                        if (filasAfectadas > 0)
                        {
                            DisplayAlert("Trabajador actualizado correctamente",
                             $"Nombre: {_nombre}\nApellidos: {_apellidos}",
                             "OK");
                        }
                        else
                        {
                            DisplayAlert("Error", "No se pudo actualizado el trabajador.", "OK");
                        }
                        
                    }
                    connection.Close();
                    
                }
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", $"Error al insertar en la base de datos: {ex.Message}", "OK");
            }

            // Limpiar los campos de entrada
            etNombre.Text = string.Empty;
            etApellidos.Text = string.Empty;
            
            BindingContext = this;
        }

    }

    

}
