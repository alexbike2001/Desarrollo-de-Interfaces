﻿using Ejer2.Pages;

namespace Ejer2
{
    public partial class MainPage : ContentPage
    {

        public MainPage()
        {
            InitializeComponent();
        }

        private async void btnInicio_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Pagina2());
        }
    }

}
