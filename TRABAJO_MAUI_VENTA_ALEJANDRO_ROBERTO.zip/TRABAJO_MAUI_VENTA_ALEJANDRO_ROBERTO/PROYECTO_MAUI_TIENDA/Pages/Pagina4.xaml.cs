﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejer2.Pages
{
    partial class Pagina4 : ContentPage
    {
        string producto;
        string unidades;
        string direccion;
        
        public Pagina4(string producto,string unidades)
        {
            InitializeComponent();
            this.producto = producto; 
            this.unidades = unidades;  
            
            
        }

        private async void btnVolverTo3_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }

        private async void btnSiguienteTo5_Clicked(object sender, EventArgs e)
        {
            direccion = etDireccion.Text;
            await Navigation.PushAsync(new Pagina5(producto,unidades, direccion));
        }
    }
}
