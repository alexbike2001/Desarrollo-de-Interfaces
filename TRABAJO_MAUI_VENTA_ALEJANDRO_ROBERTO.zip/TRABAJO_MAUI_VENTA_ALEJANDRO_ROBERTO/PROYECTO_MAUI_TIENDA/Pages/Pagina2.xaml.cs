﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejer2.Pages
{
    partial class Pagina2 : ContentPage
    {
        string producto;


        public Pagina2()
        {
            InitializeComponent();
        }

        private async void btnVolverTo1_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }

        private async void btnSiguienteTo3_Clicked(object sender, EventArgs e)
        {
            producto = pkProducto.SelectedItem?.ToString();

            if (String.IsNullOrEmpty(producto))
            {
                return;
            }
            await Navigation.PushAsync(new Pagina3(producto));
        }

        
    }
}
