﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejer2.Pages
{
    partial class Pagina3 : ContentPage
    {
        string producto;
        string unidades;
        
        public Pagina3(string producto)
        {
            InitializeComponent();

            this.producto = producto;  
            this.unidades = unidades;  
        }

        private async void btnVolverTo2_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }

        private async void btnSiguienteTo4_Clicked(object sender, EventArgs e)
        {
            unidades = etUnidades.Text;
            await Navigation.PushAsync(new Pagina4(producto,unidades));

        }
    }
}
