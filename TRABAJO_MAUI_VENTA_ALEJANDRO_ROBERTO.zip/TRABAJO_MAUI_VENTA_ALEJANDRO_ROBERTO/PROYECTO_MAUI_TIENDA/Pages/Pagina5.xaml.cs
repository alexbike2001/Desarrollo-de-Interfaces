﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejer2.Pages
{
    partial class Pagina5 : ContentPage
    {
        string producto;
        string unidades;
        string direccion;
        string resumen;
        

        public Pagina5(string producto,string unidades, string direccion) {

            InitializeComponent();
            this.producto = producto;
            this.unidades = unidades;
            this.direccion = direccion;
            resumen = "El resumen de la compra es :\n Producto : "+ unidades +" kg de "+ producto +"\n Dirección : " + direccion;

            lblResumen.Text = resumen;

        }

        private async void btnVolverTo4_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();

        }
    }
}
