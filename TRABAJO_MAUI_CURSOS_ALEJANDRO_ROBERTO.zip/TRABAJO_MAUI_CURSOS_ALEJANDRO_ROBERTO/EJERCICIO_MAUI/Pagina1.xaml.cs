using Microsoft.Maui.Graphics.Text;

namespace EJER_UD02v5;

[QueryProperty(nameof(PrecioInicial), "precioInicial")]
[QueryProperty(nameof(FormaPago), "formaPago")]
[QueryProperty(nameof(NombreCurso), "nombreCurso")]

public partial class Pagina1 : ContentPage
{
    static double _precioInicial;
    static string _formaPago;
    static string _nombreCurso;
    

    
    public string NombreCurso
    {
        get { return _nombreCurso; }
        set
        {
            _nombreCurso = value;
            OnPropertyChanged();
            
        }
    }
    public double PrecioInicial
    {
        get { return _precioInicial; }
        set
        {
            _precioInicial = value;
            OnPropertyChanged();
            
        }
    }

    public string FormaPago
    {
        get { return _formaPago; }
        set
        {
            _formaPago = value;
            
            tvFormaPago.Text = _formaPago;
            OnPropertyChanged();
           
        }
    }


    private void OnDatosDevueltos()
    {
        // Mostrar una alerta con los datos almacenados
        DisplayAlert("Datos almacenados", $"NombreCurso: {_nombreCurso}, PrecioInicial: {_precioInicial}, FormaPago: {_formaPago}", "OK");

        
    }
    public Pagina1()
    {
        InitializeComponent();
        BindingContext = this;

        if ((string.IsNullOrWhiteSpace(_nombreCurso))&& (string.IsNullOrWhiteSpace(_formaPago)))
        {
            btnCalcularPrecio.IsEnabled = false;
        }
        else
        {
            btnCalcularPrecio.IsEnabled = true;
        }
    }
    private async void btnSeleccionarCurso_Clicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync($"Pagina2");
    }

    private async void btnSeleccionarPago_Clicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync($"Pagina3");
    }

    

    private void btnCalcularPrecio_Clicked(object sender, EventArgs e)
    {
        
        if (_formaPago.Equals("Efectivo"))
        {
            string precioEfectivo = _precioInicial.ToString();
            tvCalcularPrecio.Text = precioEfectivo;
            OnPropertyChanged();
        }
        if (_formaPago.Equals("Tarjeta"))
        {
            double calculo = _precioInicial * 0.9;
            string precioTarjeta = calculo.ToString();
            tvCalcularPrecio.Text = precioTarjeta;
            OnPropertyChanged();
        }
    }

}