namespace EJER_UD02v5;

public partial class Pagina3 : ContentPage
{
	public Pagina3()
	{
        
        InitializeComponent();
	}

    private async void btnEfectivo_Clicked(object sender, EventArgs e)
    {
        string formaPago;
        await Shell.Current.GoToAsync("Pagina1?formaPago=Efectivo");
    }

    private async void btnTarjeta_Clicked(object sender, EventArgs e)
    {
        string formaPago;
        await Shell.Current.GoToAsync("Pagina1?formaPago=Tarjeta");
    }
}