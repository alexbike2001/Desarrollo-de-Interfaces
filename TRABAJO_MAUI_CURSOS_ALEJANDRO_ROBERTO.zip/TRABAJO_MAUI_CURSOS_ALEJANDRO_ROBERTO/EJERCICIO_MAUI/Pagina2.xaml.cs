namespace EJER_UD02v5;

public partial class Pagina2 : ContentPage
{
	public Pagina2()
	{
        InitializeComponent();
	}

    private async void btnCursoLlados_Clicked(object sender, EventArgs e)
    {
        string nombreCurso="Curso Llados";
        string precioInicial="1000";

        await Shell.Current.GoToAsync("Pagina1?precioInicial=1000&nombreCurso=Curso Llados");
    }

    private async void btnCursoJava_Clicked(object sender, EventArgs e)
    {
        string nombreCurso= "Curso Java";
        string precioInicial="50";
        await Shell.Current.GoToAsync("Pagina1?precioInicial=50&nombreCurso=Curso Java");
    }
}