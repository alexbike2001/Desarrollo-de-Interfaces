﻿namespace EJER_UD02v5
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
            Routing.RegisterRoute("Pagina1", typeof(Pagina1));
            Routing.RegisterRoute("Pagina2", typeof(Pagina2));
            Routing.RegisterRoute("Pagina3", typeof(Pagina3));
        }

    }
}
