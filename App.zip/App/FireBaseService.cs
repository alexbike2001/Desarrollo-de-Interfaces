﻿using Firebase.Database;
using Firebase.Database.Query;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AppTareas.Services
{
    public class FirebaseService
    {
        private readonly FirebaseClient _firebaseClient;

        public FirebaseService()
        {
            _firebaseClient = new FirebaseClient("https://ejerbotones12-a3b636ec-default-rtdb.europe-west1.firebasedatabase.app/");
        }

        public async Task AddTarea(string descripcion)
        {
            await _firebaseClient
                .Child("Tareas")
                .PostAsync(new Tarea { Descripcion = descripcion });
        }

        public async Task UpdateTarea(Tarea tarea)
        {
            if (string.IsNullOrEmpty(tarea.Id))
            {
                throw new ArgumentException("La tarea debe tener un ID válido.");
            }

            // Actualizamos solo la descripción de la tarea
            await _firebaseClient
                .Child("Tareas")
                .Child(tarea.Id)
                .PatchAsync(new { Descripcion = tarea.Descripcion });
        }

        public async Task DeleteTarea(string id)
        {
            await _firebaseClient
                .Child("Tareas")
                .Child(id)
                .DeleteAsync();
        }

        public async Task<List<Tarea>> GetTareas()
        {
            var tareas = await _firebaseClient
                .Child("Tareas")
                .OnceAsync<Tarea>();

            return tareas.Select(t => new Tarea
            {
                Id = t.Key,
                Descripcion = t.Object.Descripcion
            }).ToList();
        }

        

        


    }
}
