﻿using AppTareas.Services;
using System.Collections.ObjectModel;

namespace AppTareas;

public partial class MainPage : ContentPage
{
    private readonly FirebaseService _firebaseService;
    public ObservableCollection<Tarea> Tareas { get; set; }

    public String tareaSeleccionada;
    public String idTareaSelecionada;
    

    private Tarea _selectedTarea;
    public Tarea SelectedTarea
    {
        get => _selectedTarea;
        set
        {
                _selectedTarea = value;
                OnPropertyChanged();
        }
    }


    public MainPage()
    {
        InitializeComponent();
        _firebaseService = new FirebaseService();
        Tareas = new ObservableCollection<Tarea>();
        BindingContext = this; // Establecer el BindingContext
    }

    private async void btnInsertar_Clicked(object sender, EventArgs e)
    {
        //Inserta la tarea escrita en el Entry
        if (!string.IsNullOrEmpty(etTarea.Text))
        {
            await _firebaseService.AddTarea(etTarea.Text);
            await LoadTareas();
            etTarea.Text = string.Empty;
        }
    }

    private async void btnBorrar_Clicked(object sender, EventArgs e)
    {
        await _firebaseService.DeleteTarea(idTareaSelecionada);
        DisplayAlert("Tarea Borrada",
                         $"Tarea: {SelectedTarea.Descripcion}",
                         "OK");
        await LoadTareas();
        etTarea.Text = string.Empty;
    }

    private async void btnActualizar_Clicked(object sender, EventArgs e)
    {
        if (SelectedTarea != null && !string.IsNullOrEmpty(etTarea.Text))
        {
            SelectedTarea.Descripcion = etTarea.Text;

            // Llama al servicio para actualizar la tarea en Firebase
            await _firebaseService.UpdateTarea(SelectedTarea);

            // Recarga la lista de tareas para reflejar los cambios
            await LoadTareas();

            // Limpia el Entry después de actualizar
            etTarea.Text = string.Empty;
        }
        else
        {
            await DisplayAlert("Error", "Selecciona una tarea y asegúrate de que la descripción no esté vacía.", "OK");
        }
    }

    private async Task LoadTareas()
    {
        var tareasFirebase = await _firebaseService.GetTareas();
        Tareas.Clear();
        foreach (var tarea in tareasFirebase)
        {
            Tareas.Add(tarea);
        }
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await LoadTareas();
    }


    private void OnPropertyChanged()
    {
        base.OnPropertyChanged();
        // Cuando la propiedad selectedTarea cambia, actualiza el Entry
        if (SelectedTarea != null)
        {
            DisplayAlert("Tarea Seleccionada",
                         $"Tarea: {SelectedTarea.Descripcion}",
                         "OK");
            idTareaSelecionada = SelectedTarea.Id;
            tareaSeleccionada = SelectedTarea.Descripcion;
            etTarea.Text = tareaSeleccionada;


        }
    }

}
